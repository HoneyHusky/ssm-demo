create
    definer = root@localhost procedure create_data()
BEGIN
DECLARE i INT;      
SET i=1;
WHILE i<1000001 DO  
    INSERT INTO t_user (NAME,address,phone,age)
    VALUES(rand_string(10),rand_string(10),rand_string(10),i); 
SET i=i+1;      
END WHILE;
END;

