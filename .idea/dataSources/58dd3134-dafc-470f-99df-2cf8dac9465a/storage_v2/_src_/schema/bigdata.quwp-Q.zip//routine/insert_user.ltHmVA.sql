create
    definer = root@localhost procedure insert_user(IN start int(10), IN max_num int(10))
begin
declare i int default 0; 
set autocommit = 0; 
repeat
set i = i + 1;
insert into tbl_user_no_part values ((start+i) ,rand_string(8), concat(rand_string(6), '@random.com'), 1+FLOOR(RAND()*100), 3, now());
until i = max_num
end repeat;
commit;
end;

